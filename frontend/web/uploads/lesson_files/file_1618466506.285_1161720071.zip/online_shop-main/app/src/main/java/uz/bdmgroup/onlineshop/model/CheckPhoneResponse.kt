package uz.bdmgroup.onlineshop.model

data class CheckPhoneResponse(
    val is_reg: Boolean
)