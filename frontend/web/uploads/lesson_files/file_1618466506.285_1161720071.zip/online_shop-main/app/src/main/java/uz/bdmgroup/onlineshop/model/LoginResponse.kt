package uz.bdmgroup.onlineshop.model

data class LoginResponse(
    val token: String
)