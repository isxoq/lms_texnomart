package uz.bdmgroup.onlineshop.model

data class OfferModel(
    val id: Int,
    val image: String
)