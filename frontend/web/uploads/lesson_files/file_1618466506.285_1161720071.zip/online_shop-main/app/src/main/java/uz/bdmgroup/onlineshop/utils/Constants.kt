package uz.bdmgroup.onlineshop.utils

object Constants {
    const val BASE_URL = "http://osonsavdo.sd-group.uz/api/"
    const val HOST_IMAGE = "http://osonsavdo.sd-group.uz/images/"
    const val EXTRA_DATA = "extra_data"
    const val SHARED_PREF_NAME = "online_shop"
}